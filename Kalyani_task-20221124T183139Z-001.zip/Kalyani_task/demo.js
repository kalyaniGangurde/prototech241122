import * as THREE from 'three'
import { Light } from 'three';
import { OrbitControls } from './OrbitControls.js'


var camera, renderer, cube, scene, controls, sphere, cylinder, directionalLight, light;


init();
animate();

function init() {
    scene = new THREE.Scene();

    let mycanvas = document.getElementById("MyCanvas");
    const width = mycanvas.clientWidth;
    const height = mycanvas.clientHeight;

    camera = new THREE.PerspectiveCamera(45, width / height, 1, 1000);
    scene.add(camera);
    camera.position.set(0, 20, 100);

    renderer = new THREE.WebGLRenderer();
    renderer.setPixelRatio(window.devicePixelRatio);
    renderer.setSize(width, height);
    mycanvas.appendChild(renderer.domElement);

    controls = new OrbitControls(camera, renderer.domElement);

    // directionalLight = new THREE.DirectionalLight( 0xffffff, 0.5 );
    // scene.add( directionalLight );

    light = new THREE.HemisphereLight(0xffffbb, 0x080820, 1);
    scene.add(light);


}

// document.getElementById("Sphere1").onclick = function () {
//   let Sphere=scene.getObjectByName("Sphere");
//   if (Sphere){
//     removeSphere();
//     addCone();
//   }
// else{
//     removeCone();
//     addSphere();
// }

// }





document.getElementById("toggle").onclick = function () {

    var object = scene.getObjectByName("Cube");
    if (object) {
        // console.log(object);
        object.material.wireframe=!object.material.wireframe;
    }
        // if(true===object.material.wireframe)
        //  {
        //     object.material.wireframe=false;
        // }
        // else
        // {
        //     object.material.wireframe=true;
        // }
    }
    // object = scene.getObjectByName("Sphere");

    // if (object) {
    //     // console.log(object);
    //     object.material.wireframe=!object.material.wireframe;
    // }
    // if (object) {
    //     if(true===object.material.wireframe)
    //      {
    //         object.material.wireframe=false;
    //     }
    //     else
    //     {
    //         object.material.wireframe=true;
    //     }
    // }
    
    // object = scene.getObjectByName("Cone");

    // if (object) {
    //     // console.log(object);
    //     object.material.wireframe=!object.material.wireframe;
    // }
    // if (object) {
    //     if(true===object.material.wireframe)
    //      {
    //         object.material.wireframe=false;
    //     }
    //     else
    //     {
    //         object.material.wireframe=true;
    //     }
    // }

    // object = scene.getObjectByName("Cylinder");

    // if (object) {
    //     // console.log(object);
    //     object.material.wireframe=!object.material.wireframe;

    // if (object) {
    //     if(true===object.material.wireframe)
    //      {
    //         object.material.wireframe=false;
    //     }
    //     else
    //     {
    //         object.material.wireframe=true;
    //     }
    // }




// function RemoveObject()
// {
//     var object = scene.getObjectByName("Cube");

// }

document.getElementById("c").onclick = function () {

    var object = scene.getObjectByName("Cube");

    if (object) {
        object.geometry.dispose();
        object.material.dispose();
        scene.remove(object);

    }

    object = scene.getObjectByName("Sphere");

    if (object) {
        object.geometry.dispose();
        object.material.dispose();
        scene.remove(object);

    }
    object = scene.getObjectByName("Cone");

    if (object) {
        object.geometry.dispose();
        object.material.dispose();
        scene.remove(object);

    }
    object = scene.getObjectByName("Cylinder");


    if (object) {
        object.geometry.dispose();
        object.material.dispose();
        scene.remove(object);

    }

    const geometry = new THREE.BoxGeometry(11, 11, 11);
    const material = new THREE.MeshPhongMaterial({ color: 0xFFA500 });
    cube = new THREE.Mesh(geometry, material);
    cube.name = "Cube";
    scene.add(cube);
    camera.position.z = 10;


}



document.getElementById("s").onclick = function () {

    var object = scene.getObjectByName("Sphere");

    if (object) {
        object.geometry.dispose();
        object.material.dispose();
        scene.remove(object);

    }

    object = scene.getObjectByName("Cube");

    if (object) {
        object.geometry.dispose();
        object.material.dispose();
        scene.remove(object);

    }
    object = scene.getObjectByName("Cone");

    if (object) {
        object.geometry.dispose();
        object.material.dispose();
        scene.remove(object);

    }
    object = scene.getObjectByName("Cylinder");


    if (object) {
        object.geometry.dispose();
        object.material.dispose();
        scene.remove(object);

    }

    const geometry = new THREE.SphereGeometry(5, 15, 10);
    const material = new THREE.MeshPhongMaterial({ color: 0xffff00 });
    sphere = new THREE.Mesh(geometry, material);
    sphere.name = "Sphere";
    scene.add(sphere);
    camera.position.z = 10;
}

document.getElementById("cone").onclick = function () {

    var object = scene.getObjectByName("Cone");

    if (object) {
        object.geometry.dispose();
        object.material.dispose();
        scene.remove(object);

    }

    object = scene.getObjectByName("Cube");

    if (object) {
        object.geometry.dispose();
        object.material.dispose();
        scene.remove(object);

    }

    object = scene.getObjectByName("Sphere");

    if (object) {
        object.geometry.dispose();
        object.material.dispose();
        scene.remove(object);

    }
    object = scene.getObjectByName("Cylinder");


    if (object) {
        object.geometry.dispose();
        object.material.dispose();
        scene.remove(object);

    }
    const geometry = new THREE.ConeGeometry(5, 20, 32);
    const material = new THREE.MeshPhongMaterial({ color: 0xDE3163 });
    const cone = new THREE.Mesh(geometry, material);
    cone.name = "Cone";
    scene.add(cone);

}

document.getElementById("cy").onclick = function () {
    var object = scene.getObjectByName("Cylinder");


    if (object) {
        object.geometry.dispose();
        object.material.dispose();
        scene.remove(object);

    }

    object = scene.getObjectByName("Cube");

    if (object) {
        object.geometry.dispose();
        object.material.dispose();
        scene.remove(object);

    }

    object = scene.getObjectByName("Sphere");

    if (object) {
        object.geometry.dispose();
        object.material.dispose();
        scene.remove(object);

    }
    object = scene.getObjectByName("Cone");

    if (object) {
        object.geometry.dispose();
        object.material.dispose();
        scene.remove(object);

    }

    const geometry = new THREE.CylinderGeometry(5, 5, 20, 32);
    const material = new THREE.MeshPhongMaterial({ color: 0xAA4A44 });
    cylinder = new THREE.Mesh(geometry, material);
    cylinder.name = "Cylinder";
    scene.add(cylinder);
    camera.position.z = 10;
}



function animate() {

    requestAnimationFrame(animate);
    renderer.render(scene, camera);
    controls.update();
}