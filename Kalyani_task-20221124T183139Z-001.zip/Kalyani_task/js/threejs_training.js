import * as THREE from 'three'
import { Light } from 'three';
import { OrbitControls } from './OrbitControls.js'
// import { STLLoader } from 'three/examples/jsm/loaders/STLLoader';


var camera, renderer, cube, scene, controls, sphere, cylinder, directionalLight, light,scene1,camera1,renderer1;


init();
animate();

function init() {
    scene = new THREE.Scene();

    let mycanvas = document.getElementById("MyCanvas");
    const width = mycanvas.clientWidth;
    const height = mycanvas.clientHeight;

    camera = new THREE.PerspectiveCamera(45, width / height, 1, 1000);
    scene.add(camera);
    camera.position.set(0, 20, 100);

    // controls = new DragControls( [ ... objects ], camera, renderer.domElement );
	// controls.addEventListener( 'drag', render );

    
    renderer = new THREE.WebGLRenderer();
    renderer.setPixelRatio(window.devicePixelRatio);
    renderer.setSize(width, height);
    mycanvas.appendChild(renderer.domElement);

    controls = new OrbitControls(camera, renderer.domElement);

    // directionalLight = new THREE.DirectionalLight( 0xffffff, 0.5 );
    // scene.add( directionalLight );

    light = new THREE.HemisphereLight(0xffffbb, 0x080820, 1);
    scene.add(light);
    
    let mycanvas1 = document.getElementById("box");
    const width1 = mycanvas1.clientWidth;
    const height1 = mycanvas1.clientHeight;
    scene1 = new THREE.Scene();
    camera1 = new THREE.PerspectiveCamera(45, width1 / height1, 1, 1000);
    scene1.add(camera1);
    camera1.position.set(0, 20, 100);
    renderer1= new THREE.WebGLRenderer();
    renderer1.setPixelRatio(window.devicePixelRatio);
    renderer1.setSize(width1, height1);
    mycanvas1.appendChild(renderer1.domElement);
    
    const axesHelper = new THREE.AxesHelper( 15 );
    scene1.add( axesHelper );
    axesHelper.position.set (0,0,0);
    renderer1.render (scene1,camera1)
}

// const loader = new STLLoader()
// loader.load(
//     './example.stl',
//     function (geometry) {
//         const mesh = new THREE.Mesh(geometry, material);
//         scene.add(mesh);
//     },
//     (xhr) => {
//         console.log((xhr.loaded / xhr.total) * 100 + '% loaded')
//     },
//     (error) => {
//         console.log(error)
//     }
// )

// document.getElementById("s").onclick = function () {
//   let Sphere=scene.getObjectByName("Sphere");
//   if (Sphere){
//     removeSphere();
//     addCone();
//   }
// else{
//     removeCone();
//     addSphere();
// }

// }





document.getElementById("toggle").onclick = function () {

    var object = scene.getObjectByName("Cube");
    if (object) {
        // console.log(object);
        object.material.wireframe=!object.material.wireframe;
    }
        
    
    object = scene.getObjectByName("Sphere");

    if (object) {
        // console.log(object);
        object.material.wireframe=!object.material.wireframe;
    }
    
    
    object = scene.getObjectByName("Cone");

    if (object) {
        // console.log(object);
        object.material.wireframe=!object.material.wireframe;
    }
 

    object = scene.getObjectByName("Cylinder");

    if (object) {
        // console.log(object);
        object.material.wireframe=!object.material.wireframe;

    }

}

// function RemoveObject()
// {
//     var object = scene.getObjectByName("Cube");

// }

document.getElementById("c").onclick = function () {

 let Wireframe = true;
    var object = scene.getObjectByName("Cube");

    if (object) {

        Wireframe =!object.material.wireframe;
        object.geometry.dispose();
        object.material.dispose();
        scene.remove(object);

    }

    object = scene.getObjectByName("Sphere");

    if (object) {
        object.geometry.dispose();
        object.material.dispose();
        scene.remove(object);

    }
    object = scene.getObjectByName("Cone");

    if (object) {
        object.geometry.dispose();
        object.material.dispose();
        scene.remove(object);

    }
    object = scene.getObjectByName("Cylinder");


    if (object) {
        object.geometry.dispose();
        object.material.dispose();
        scene.remove(object);

    }


    const geometry = new THREE.BoxGeometry(11, 11, 11);
    const material = new THREE.MeshPhongMaterial({ color: 0xFFA500,wireframe:Wireframe });
    cube = new THREE.Mesh(geometry, material);
    cube.name = "Cube";
    scene.add(cube);
    camera.position.z = 10;


}



document.getElementById("s").onclick = function () {

    let StatusOfWireframe = true;

    var object = scene.getObjectByName("Sphere");

    if (object) {

        StatusOfWireframe =!object.material.wireframe;
        object.geometry.dispose();
        object.material.dispose();
        scene.remove(object);

    }

    object = scene.getObjectByName("Cube");

    if (object) {
        object.geometry.dispose();
        object.material.dispose();
        scene.remove(object);

    }
    object = scene.getObjectByName("Cone");

    if (object) {
        object.geometry.dispose();
        object.material.dispose();
        scene.remove(object);

    }
    object = scene.getObjectByName("Cylinder");


    if (object) {
        object.geometry.dispose();
        object.material.dispose();
        scene.remove(object);

    }

    const geometry = new THREE.SphereGeometry(5, 15, 10);
    const material = new THREE.MeshPhongMaterial({ color: 0xffff00,wireframe:StatusOfWireframe });
    sphere = new THREE.Mesh(geometry, material);
    sphere.name = "Sphere";
    scene.add(sphere);
    camera.position.z = 10;
}

document.getElementById("cone").onclick = function () {
    let StatusOfWireframe = true;
 

    var object = scene.getObjectByName("Cone");

    if (object) {
        StatusOfWireframe =!object.material.wireframe;
        object.geometry.dispose();
        object.material.dispose();
        scene.remove(object);

    }

    object = scene.getObjectByName("Cube");

    if (object) {
        object.geometry.dispose();
        object.material.dispose();
        scene.remove(object);

    }

    object = scene.getObjectByName("Sphere");

    if (object) {
        object.geometry.dispose();
        object.material.dispose();
        scene.remove(object);

    }
    object = scene.getObjectByName("Cylinder");


    if (object) {
        object.geometry.dispose();
        object.material.dispose();
        scene.remove(object);

    }
    const geometry = new THREE.ConeGeometry(5, 20, 32);
    const material = new THREE.MeshPhongMaterial({ color: 0xDE3163,wireframe:StatusOfWireframe });
    const cone = new THREE.Mesh(geometry, material);
    cone.name = "Cone";
    scene.add(cone);

}

document.getElementById("cy").onclick = function () {

    let StatusOfWireframe = true;
    var object = scene.getObjectByName("Cylinder");


    if (object) {
        StatusOfWireframe =!object.material.wireframe;
        object.geometry.dispose();
        object.material.dispose();
        scene.remove(object);

    }

    object = scene.getObjectByName("Cube");

    if (object) {
        object.geometry.dispose();
        object.material.dispose();
        scene.remove(object);

    }

    object = scene.getObjectByName("Sphere");

    if (object) {
        object.geometry.dispose();
        object.material.dispose();
        scene.remove(object);

    }
    object = scene.getObjectByName("Cone");

    if (object) {
        object.geometry.dispose();
        object.material.dispose();
        scene.remove(object);

    }

    const geometry = new THREE.CylinderGeometry(5, 5, 20, 32);
    const material = new THREE.MeshPhongMaterial({ color: 0xAA4A44,wireframe:StatusOfWireframe });
    cylinder = new THREE.Mesh(geometry, material);
    cylinder.name = "Cylinder";
    scene.add(cylinder);
    camera.position.z = 10;
}



function animate() {

    requestAnimationFrame(animate);
    renderer.render(scene, camera);
    controls.update();
    camera1.position.copy(camera.position)
    renderer1.render(scene1, camera1);
    camera1.lookAt(0,0,0)
    
}